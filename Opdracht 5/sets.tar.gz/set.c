#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "set.h"
#include "tree.h"

struct set {

    // ... SOME CODE MISSING HERE ...
};

struct set *set_init(int turbo) {

    // ... SOME CODE MISSING HERE ...
}

int set_insert(struct set *s, int num) {

    // ... SOME CODE MISSING HERE ...
}

int set_find(struct set *s, int num) {

    // ... SOME CODE MISSING HERE ...
}

int set_remove(struct set *s, int num) {

    // ... SOME CODE MISSING HERE ...
}

void set_cleanup(struct set *s) {

    // ... SOME CODE MISSING HERE ...
}

void set_print(struct set *s) {

    // ... SOME CODE MISSING HERE ...
}

int set_verify(struct set *s) {

    // ... SOME CODE MISSING HERE ...
}
